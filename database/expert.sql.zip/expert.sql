-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2020 at 01:49 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expert`
--

-- --------------------------------------------------------

--
-- Table structure for table `response`
--

CREATE TABLE `response` (
  `id` varchar(255) NOT NULL,
  `answers` varchar(255) NOT NULL,
  `effect` varchar(255) NOT NULL,
  `ids` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `response`
--

INSERT INTO `response` (`id`, `answers`, `effect`, `ids`) VALUES
('admin', 'Dry cough', 'High', 1),
('admin', 'Pales eyes', 'Low', 2),
('admin', 'Fever and Headache', 'Moderate', 3),
('admin', 'Vomiting', 'Low', 4),
('admin', 'Constipation', 'High', 5),
('admin', 'Loss of appetite and confusion', 'Moderate', 6),
('admin', 'Dizziness', 'Low', 7),
('admin', 'Joint ', 'Moderate', 8),
('admin', 'Disorientation', 'Moderate', 9);

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

CREATE TABLE `symptoms` (
  `id` int(11) NOT NULL,
  `symptom` varchar(255) NOT NULL,
  `impact` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `symptoms`
--

INSERT INTO `symptoms` (`id`, `symptom`, `impact`) VALUES
(1, 'Dry cough', 'High'),
(2, 'Pales eyes', 'High'),
(3, 'Malaise', 'High'),
(4, 'Rose spot', 'High'),
(5, 'Fever and Headache', 'High'),
(6, 'Vomiting', 'High'),
(7, 'Diarrhea', 'High'),
(8, 'Constipation', 'High'),
(9, 'Dizziness', 'High'),
(10, 'Loss of appetite and confusion', 'High'),
(11, 'Disorientation', 'High'),
(12, 'Cold chills', 'High'),
(13, 'Nose bleeding', 'High'),
(14, 'Bleeding from the eyes & ear', 'High'),
(15, 'Joint ', 'High'),
(16, 'Dark Urine', 'High');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `gender` char(6) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`fullname`, `username`, `gender`, `password`, `id`) VALUES
('David Akwuru', 'dayboy20', 'Male', 'dd359640ce83a5d5525a4cd98eda285f25e82d08', 2),
('uche willl', 'uchewill', 'Male', '29c1ead25ea5340bcdbbfc48978dd2e2bfc4fa9d', 3),
('Dayboy20', 'louis', 'Male', 'dd359640ce83a5d5525a4cd98eda285f25e82d08', 4),
('Victor', 'vick', 'Male', '7c4a8d09ca3762af61e59520943dc26494f8941b', 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `response`
--
ALTER TABLE `response`
  ADD PRIMARY KEY (`ids`);

--
-- Indexes for table `symptoms`
--
ALTER TABLE `symptoms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `response`
--
ALTER TABLE `response`
  MODIFY `ids` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `symptoms`
--
ALTER TABLE `symptoms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
